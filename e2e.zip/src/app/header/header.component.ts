import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function () {
      $(".dropdown,.dropbtn").mouseover(function () {
        $(this).find(".dropdown-content").css("display", "block");
        $(this).find(".caret-wrapper").css("display", "block");
      });
      $(".dropdown,.dropbtn").mouseout(function () {
        $(this).find(".dropdown-content").css("display", "none");
        $(this).find(".caret-wrapper").css("display", "none");
      });
    });
  }

}
