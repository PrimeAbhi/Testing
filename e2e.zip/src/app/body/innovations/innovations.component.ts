import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innovations',
  templateUrl: './innovations.component.html',
  styleUrls: ['./innovations.component.css']
})
export class InnovationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
